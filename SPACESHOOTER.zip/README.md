Space Wars is  a 2d game made with Pygame which is a library that is probably the most well-known Python library when it comes to making games. It’s not the most advanced or high-level library, but it’s comparatively simple and easy to learn. Pygame is a great entry point into the graphics and game development world, especially for beginners.
The Pygame framework includes several modules with functions for drawing graphics, playing sounds, handling mouse input, and other things you’ll need while developing games in Python.

In the game I have managed to do most of the necessary stuff, from there on the remaining bit will be done after further learning of the library
